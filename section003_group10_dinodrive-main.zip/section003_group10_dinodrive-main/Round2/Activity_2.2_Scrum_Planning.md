Please discuss and answer the following questions.
 What are the specific goals for this round? Aside from meeting this round’s design review deliverables,
what are your own goals?
 What are the backlog items from last round?
 What are the tasks needed to achieve each goal, including the backlog items?
 Who is responsible for each task/goal?