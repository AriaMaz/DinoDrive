From Workshop 3.2 Let’s summarize your design so far in a FRDPARRC Table. For Strategy, you
only need to list one functional requirement and design parameter. For Concept, please list 2-3 design
parameters, including the one you chose for building your cardboard prototype.

Need to change contents of table below.

| Action | Points |
| --- | --- |
| Exit gate autonomously using push button | 8 |
| Exit gate autonomously using line following | 4 |
| Dinosaurs corralled | Max 6 (scaled to number in corral)|
| Doll saved (from pit to helipad) | Max 6 (scaled to the accelerometer)|